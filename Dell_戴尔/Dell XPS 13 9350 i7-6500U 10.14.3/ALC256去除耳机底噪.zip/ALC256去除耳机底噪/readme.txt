1.Id：注入56（16进制：0x38）
2.acpi对应2个hotpatch文件，SSDT-HDEF.aml已经注入id为56
3.kext文件夹有配套的Lilu（1.2.1）和AppleALC驱动，拉取最新代码编译，支持id为56，不要使用其它版本，可能不支持id56
3.如果遇到外放有声,耳机无声，双击ALCPluginFix中的install双击自动安装.command
4.最后记得重建缓存：
sudo rm -rf /System/Library/Caches/com.apple.kext.caches/Startup/kernelcache
sudo rm -rf /System/Library/PrelinkedKernels/prelinkedkernel
sudo touch /System/Library/Extensions/ && sudo kextcache -u /